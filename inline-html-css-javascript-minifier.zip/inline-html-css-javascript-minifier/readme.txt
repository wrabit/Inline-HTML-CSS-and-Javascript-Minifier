=== Plugin Name ===

Contributors: Will Abbott
Plugin Name: Inline HTML, CSS & Javascript Minifier
Plugin URI: https://github.com/digitaloutback/Inline-HTML-CSS-and-Javascript-Minifier
Tags: minify, inline, html, css, javascript, speed
Author URI: http://digitaloutback.co.uk
Author: Digital Outback
Requires at least: 2.3
Tested up to: 2.9
Stable tag: 1.0
Version: 1.0 

== Description ==

This plugin was derived from a simple observation - I could not find a plugin that successfully minified my front-end - HTML, CSS and Javascript.

== Installation ==

Either install via WP Admin / Plugins or copy the files to wp-content/plugins. Once activated, you can go to Settings > Inline HTML, CSS & Javascript Minifier to set what gets minified. By default all three HTML, CSS and Javascript are minified.

== Upgrade Notice ==

== Screenshots ==

== Changelog ==

== Frequently Asked Questions ==

== Donations ==